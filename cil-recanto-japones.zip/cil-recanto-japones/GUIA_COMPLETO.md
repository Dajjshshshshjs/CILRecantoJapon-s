# 📚 Guia Completo - CIL Recanto Japonês

## Índice
1. [Visão Geral](#visão-geral)
2. [Instalação e Configuração](#instalação-e-configuração)
3. [Guia do Aluno](#guia-do-aluno)
4. [Guia do Administrador](#guia-do-administrador)
5. [Recursos Técnicos](#recursos-técnicos)
6. [FAQ](#faq)

---

## Visão Geral

O CIL Recanto Japonês é uma plataforma de aprendizado interativa que combina:
- **Parte Estudante**: Interface amigável para aprender japonês
- **Parte Admin**: Painel completo para gerenciar curso e alunos

### Princípios Pedagógicos
- 📈 Aprendizado progressivo (Hiragana → Katakana → Kanji → Vocabulário)
- 🎯 Rastreamento individual de progresso
- 📊 Feedback em tempo real
- 🏆 Sistema motivacional com conquistas

---

## Instalação e Configuração

### Requisitos Mínimos
- Node.js versão 18 ou superior
- Navegador moderno (Chrome, Firefox, Safari, Edge)
- 50MB de espaço em disco

### Passo 1: Extrair Arquivos
```bash
unzip cil-recanto-japones.zip
cd cil-recanto-japones
```

### Passo 2: Instalar Dependências
```bash
npm install
```

### Passo 3: Iniciar Servidor
```bash
npm start
```

Você verá a mensagem:
```
🇯🇵 CIL Recanto Japonês - Servidor rodando em http://localhost:3000
```

### Passo 4: Acessar no Navegador
- Dashboard: `http://localhost:3000`
- Admin: `http://localhost:3000/admin`

---

## Guia do Aluno

### Primeira Visita

#### 1. Criar Conta
1. Acesse `http://localhost:3000`
2. Clique em "Registre-se"
3. Preencha:
   - **Nome**: Seu nome completo
   - **Email**: Email único (não pode repetir)
   - **Senha**: Mínimo 6 caracteres (recomendado 8+)

#### 2. Primeiro Login
```
Email: seu@email.com
Senha: sua_senha_aqui
```

### Dashboard Principal

Após login, você verá:

**📊 Estatísticas Pessoais**
- Respostas Corretas: Total de acertos
- Total de Atividades: Quantas exercícios completou
- Taxa de Acerto: Porcentagem (Corretos ÷ Total)
- Dias de Sequência: Número de dias estudando consecutivos

**📚 Módulos de Aprendizado**

#### Hiragana (あいうえお)
- 46 caracteres básicos do japonês
- Padrão: 69% concluído
- Clique para ver lições detalhadas
- **Tempo estimado**: 3-4 semanas
- **Dica**: Pratique 10 minutos por dia

#### Katakana (アイウエオ)
- 46 caracteres para palavras estrangeiras
- Similar ao Hiragana em pronuncia
- **Tempo estimado**: 2-3 semanas
- **Quando estudar**: Após dominar Hiragana

#### Kanji (漢字)
- Caracteres mais complexos
- Cada um tem significado próprio
- **Total**: 159 caracteres básicos
- **Tempo estimado**: 3-6 meses
- **Dica**: Não tente decorar, aprender padrões

#### Vocabulário (語彙)
- Palavras e expressões úteis
- Contexto de uso no cotidiano
- **Total**: 72 palavras iniciais
- **Extensível**: Adicione suas próprias palavras

### Como Estudar

1. **Escolha um módulo**: Clique no card do módulo
2. **Veja os caracteres**: Cada caractere mostra:
   - Símbolo em grande
   - Pronúncia (Romaji)
   - Significado em português
3. **Pratique**: Repita 3-5 vezes
4. **Avance**: Progresso é rastreado automaticamente

### Melhorando Seu Desempenho

**Taxa de Acerto = Respostas Corretas ÷ Total de Atividades**

Exemplo:
- 100 atividades = 100 total
- 85 corretas = 85% de acerto
- Alvo: 90%+

**Dicas Práticas:**
1. Estude poucos caracteres por sessão (5-10)
2. Repita diariamente (consistência > quantidade)
3. Revise caracteres antigos regularmente
4. Associe com imagens e histórias
5. Fale em voz alta a pronúncia

### Rastreando Seu Progresso

**Atividades Recentes**
- Mostra suas últimas 10 atividades
- Data e tipo de atividade
- Ajuda a identificar padrões

**Matemática do Progresso**
```
Progresso = (Caracteres Aprendidos ÷ Total) × 100
Hiragana: 72/104 = 69%
Katakana: 0/104 = 0%
Kanji: 0/159 = 0%
Vocabulário: 7/72 = 10%
```

---

## Guia do Administrador

### Acesso ao Painel

#### Primeira Conta é Admin Automaticamente
```
Email: seu_email@admin.com
Senha: sua_senha_segura
```

#### Acessar Admin
1. Faça login como admin
2. Clique em "Perfil"
3. Clique em "Acessar Painel Admin"
4. Ou acesse direto: `http://localhost:3000/admin`

### Painel Administrativo

#### 📊 Dashboard
Visão geral do sistema com:

**Estatísticas Globais:**
- Total de Usuários
- Total de Alunos (excluindo admins)
- Progresso Médio (%)
- Total de Atividades Registradas

**Atividade Recente:**
Tabela com top 10 alunos mais ativos mostrando:
- Nome do aluno
- Email
- Acertos (respostas corretas)
- Total (atividades completadas)
- Taxa de acerto (%)

#### 👥 Gerenciar Usuários

**Listar Todos os Usuários**
Tabela com colunas:
- Nome
- Email
- Papel (Admin/Aluno)
- Acertos
- Total de Atividades
- Ações

**Editar Usuário**
Clique em "Editar" para:
1. Alterar nome
2. Mudar papel (Admin ↔ Aluno)
3. Ver/modificar acertos e totais
4. Deletar usuário (com confirmação)

**Segurança ao Deletar:**
- Confirmação necessária
- Todos os dados do usuário são removidos
- Ação irreversível

#### 📈 Análises

**Métricas Disponíveis:**
- Taxa Média de Acerto Global
- Número de Usuários Ativos
- Módulos Completados

**Interpretação de Dados:**
```
Taxa Média de Acerto = 78%
├─ Indica qualidade geral de aprendizado
├─ Alvo institucional: 75-80%
└─ Se < 70%: Revisar dificuldade do material

Usuários Ativos = 45
├─ Visitantes no último mês
├─ Crescimento esperado: 10-15% mês
└─ Se estático: Aumentar engajamento

Módulos Completados = 320
├─ Total de módulos terminados
├─ Média por aluno: 320÷50 = 6.4
└─ Acompanhar tendência
```

#### ⚙️ Configurações

**Informações do Sistema**
- Nome da Instituição (CIL Recanto Japonês)
- Email de Contato
- Telefone

**Zona de Perigo**
- Exportar Dados: Faz backup em JSON
- Arquivos: `cil-recanto-japones-backup-TIMESTAMP.json`

### Relatórios Úteis

#### Relatório de Desempenho
```
Período: Setembro 2024
Total de Alunos: 50
Ativos (últimos 30 dias): 42 (84%)
Taxa Média de Acerto: 76%
Módulo Mais Popular: Hiragana
Módulo Menos Estudado: Kanji
```

#### Plano de Ação
```
1. Investigar por que Kanji tem baixa adesão
2. Oferecer tutoriais adicionais
3. Criar grupos de estudo
4. Aumentar frequência de lembretes
```

### Tarefas Semanais Recomendadas

**Segunda-feira:**
- [ ] Verificar novos registros
- [ ] Contatar alunos inativos
- [ ] Revisar progresso geral

**Quarta-feira:**
- [ ] Analisar taxa de acerto
- [ ] Identificar alunos com dificuldades
- [ ] Atualizar conteúdo se necessário

**Sexta-feira:**
- [ ] Fazer backup dos dados
- [ ] Preparar relatório semanal
- [ ] Planejar semana seguinte

---

## Recursos Técnicos

### Estrutura de Dados

**Usuário (User)**
```json
{
  "id": 1694521800000,
  "name": "João Silva",
  "email": "joao@example.com",
  "passwordHash": "sha256_hash_da_senha",
  "role": "student|admin",
  "createdAt": "2024-09-12T11:18:00Z",
  "progress": {
    "hiragana": 69,
    "katakana": 0,
    "kanji": 0,
    "vocabulary": 10
  },
  "correctAnswers": 85,
  "totalAnswers": 100,
  "streak": 5,
  "lastStudy": "2024-09-12T11:15:00Z"
}
```

**Sessão (Session)**
```json
{
  "token": "hex_string_64_caracteres",
  "userId": 1694521800000,
  "expiresAt": 1727721800000
}
```

### API Reference

#### Autenticação

**POST /api/register**
```bash
curl -X POST http://localhost:3000/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Novo Aluno",
    "email": "aluno@example.com",
    "password": "senha123"
  }'
```

Response (201):
```json
{
  "message": "Usuário registrado com sucesso",
  "token": "abc123def456...",
  "user": {
    "id": 1694521800000,
    "name": "Novo Aluno",
    "email": "aluno@example.com",
    "role": "student"
  }
}
```

**POST /api/login**
```bash
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "aluno@example.com",
    "password": "senha123"
  }'
```

**GET /api/me**
```bash
curl http://localhost:3000/api/me \
  -H "Authorization: Bearer SEU_TOKEN_AQUI"
```

#### Admin

**GET /api/admin/users**
```bash
curl http://localhost:3000/api/admin/users \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

**PUT /api/admin/users/:id**
```bash
curl -X PUT http://localhost:3000/api/admin/users/1694521800000 \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -d '{
    "name": "Nome Atualizado",
    "role": "admin"
  }'
```

**DELETE /api/admin/users/:id**
```bash
curl -X DELETE http://localhost:3000/api/admin/users/1694521800000 \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

### Armazenamento

**Localização do Banco de Dados:**
```
./data/database.json
```

**Fazer Backup Manual:**
```bash
cp data/database.json data/database.backup.json
```

**Restaurar Backup:**
```bash
cp data/database.backup.json data/database.json
```

---

## FAQ

### Perguntas Frequentes - Alunos

**P: Esqueci minha senha. Como recupero?**
A: Atualmente, entre em contato com o administrador. Ele pode usar o painel para reset.

**P: Quanto tempo leva para aprender japonês?**
A: Depende da dedição:
- Hiragana: 3-4 semanas (10 min/dia)
- Katakana: 2-3 semanas (10 min/dia)
- Kanji Básico: 3-6 meses (30 min/dia)
- Conversação Básica: 6-12 meses

**P: Posso estudar offline?**
A: A versão atual requer conexão. Futuramente, adicionaremos modo offline.

**P: Como meu progresso é calculado?**
A: Taxa de Acerto = Respostas Corretas ÷ Total de Atividades × 100

**P: Posso resetar meu progresso?**
A: Contate o administrador. Ele pode fazer isso no painel.

### Perguntas Frequentes - Administradores

**P: Como faço backup dos dados?**
A: Use "Exportar Dados" no painel, ou copie `data/database.json` manualmente.

**P: Posso mudar alguém para admin?**
A: Sim, no painel, clique "Editar" e mude o papel para "Admin".

**P: E se alguém esquecer a senha?**
A: Atualmente sem função de reset. Futura feature: Reset por email.

**P: Quantos usuários o sistema suporta?**
A: Ilimitado (limitado apenas pela memória/disco do servidor).

**P: Posso migrar para outro servidor?**
A: Sim! Copie toda a pasta `cil-recanto-japones` e execute em outro lugar.

**P: Como faço deploy em produção?**
A: Considere:
1. Usar VPS (Digital Ocean, AWS, Azure)
2. Configurar HTTPS
3. Usar banco de dados profissional
4. Configurar domínio próprio
5. Implementar logs e monitoramento

**P: Qual é a senha padrão?**
A: Não há senha padrão. O sistema começa vazio e você cria a primeira conta.

### Troubleshooting Técnico

**Problema: Porta 3000 já em uso**
```bash
# Encontrar processo
lsof -i :3000

# Matar processo (Linux/Mac)
kill -9 <PID>

# Usar porta diferente
PORT=8080 npm start
```

**Problema: "Cannot find module"**
```bash
# Reinstalar dependências
rm -rf node_modules package-lock.json
npm install
```

**Problema: Dados Corrompidos**
```bash
# Restaurar de backup
cp data/database.backup.json data/database.json

# Ou recriar do zero
rm data/database.json
npm start  # Arquivo será recriado
```

**Problema: Páginas não carregam**
1. Limpe cache do navegador (Ctrl+Shift+Delete)
2. Verifique console (F12) para erros
3. Reinicie servidor (Ctrl+C, npm start)

---

## Próximas Funcionalidades

- [ ] Autenticação com Google/Gmail
- [ ] Reset de senha por email
- [ ] Modo escuro
- [ ] Teste de pronúncia com áudio
- [ ] Gamificação (pontos, badges)
- [ ] Competições entre alunos
- [ ] Certificado de conclusão
- [ ] Integração com Moodle
- [ ] App móvel nativa
- [ ] Suporte a temas customizados

---

**Última atualização:** 12 de Setembro de 2024

頑張ってください！(Ganbare kudasai! - Boa sorte!)
