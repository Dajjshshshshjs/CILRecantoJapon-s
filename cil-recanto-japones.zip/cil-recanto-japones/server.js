import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import { randomBytes } from 'crypto';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');

// Criar diretórios se não existirem
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Simular banco de dados em JSON
const DB_FILE = path.join(DATA_DIR, 'database.json');

// Estrutura do banco de dados
const defaultDB = {
  users: [],
  sessions: [],
  progress: [],
  achievements: [],
  admins: []
};

// Carregar ou criar banco de dados
function loadDB() {
  try {
    if (fs.existsSync(DB_FILE)) {
      return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    }
  } catch (e) {
    console.error('Erro ao carregar DB:', e);
  }
  return JSON.parse(JSON.stringify(defaultDB));
}

function saveDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// Hash de senha
function hashPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// Gerar token
function generateToken() {
  return randomBytes(32).toString('hex');
}

// Validar sessão
function validateSession(token, db) {
  const session = db.sessions.find(s => s.token === token && s.expiresAt > Date.now());
  if (session) {
    const user = db.users.find(u => u.id === session.userId);
    return user;
  }
  return null;
}

// Servir arquivo estático
function serveStatic(filePath, response) {
  const fullPath = path.join(PUBLIC_DIR, filePath);
  
  if (!fs.existsSync(fullPath)) {
    response.writeHead(404, { 'Content-Type': 'application/json' });
    response.end(JSON.stringify({ error: 'Arquivo não encontrado' }));
    return;
  }

  let contentType = 'text/plain';
  if (fullPath.endsWith('.html')) contentType = 'text/html; charset=utf-8';
  else if (fullPath.endsWith('.css')) contentType = 'text/css';
  else if (fullPath.endsWith('.js')) contentType = 'application/javascript';
  else if (fullPath.endsWith('.json')) contentType = 'application/json';
  else if (fullPath.endsWith('.png')) contentType = 'image/png';
  else if (fullPath.endsWith('.jpg') || fullPath.endsWith('.jpeg')) contentType = 'image/jpeg';
  else if (fullPath.endsWith('.svg')) contentType = 'image/svg+xml';
  else if (fullPath.endsWith('.woff2')) contentType = 'font/woff2';

  response.writeHead(200, { 'Content-Type': contentType });
  response.end(fs.readFileSync(fullPath));
}

// Parsear JSON do body
async function parseJSON(request) {
  return new Promise((resolve, reject) => {
    let data = '';
    request.on('data', chunk => {
      data += chunk;
      if (data.length > 1e6) {
        request.destroy();
        reject(new Error('Payload muito grande'));
      }
    });
    request.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (e) {
        reject(e);
      }
    });
  });
}

// Criar servidor
const server = http.createServer(async (request, response) => {
  // CORS
  response.setHeader('Access-Control-Allow-Origin', '*');
  response.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  response.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (request.method === 'OPTIONS') {
    response.writeHead(200);
    response.end();
    return;
  }

  const url = new URL(request.url, `http://${request.headers.host}`);
  const pathname = url.pathname;
  const db = loadDB();

  try {
    // Rotas de autenticação
    if (pathname === '/api/register' && request.method === 'POST') {
      const body = await parseJSON(request);
      const { name, email, password } = body;

      if (!name || !email || !password) {
        response.writeHead(400, { 'Content-Type': 'application/json' });
        response.end(JSON.stringify({ error: 'Dados inválidos' }));
        return;
      }

      if (db.users.find(u => u.email === email)) {
        response.writeHead(409, { 'Content-Type': 'application/json' });
        response.end(JSON.stringify({ error: 'Email já registrado' }));
        return;
      }

      const newUser = {
        id: Date.now(),
        name,
        email,
        passwordHash: hashPassword(password),
        role: db.users.length === 0 ? 'admin' : 'student',
        createdAt: new Date().toISOString(),
        progress: { hiragana: 0, katakana: 0, kanji: 0, vocabulary: 0 },
        streak: 0,
        lastStudy: null,
        correctAnswers: 0,
        totalAnswers: 0
      };

      db.users.push(newUser);
      saveDB(db);

      const token = generateToken();
      db.sessions.push({
        token,
        userId: newUser.id,
        expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000
      });
      saveDB(db);

      response.writeHead(201, { 'Content-Type': 'application/json' });
      response.end(JSON.stringify({
        message: 'Usuário registrado com sucesso',
        token,
        user: {
          id: newUser.id,
          name: newUser.name,
          email: newUser.email,
          role: newUser.role
        }
      }));
      return;
    }

    // Login
    if (pathname === '/api/login' && request.method === 'POST') {
      const body = await parseJSON(request);
      const { email, password } = body;

      const user = db.users.find(u => u.email === email && u.passwordHash === hashPassword(password));

      if (!user) {
        response.writeHead(401, { 'Content-Type': 'application/json' });
        response.end(JSON.stringify({ error: 'Email ou senha inválidos' }));
        return;
      }

      const token = generateToken();
      db.sessions.push({
        token,
        userId: user.id,
        expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000
      });
      saveDB(db);

      response.writeHead(200, { 'Content-Type': 'application/json' });
      response.end(JSON.stringify({
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role
        }
      }));
      return;
    }

    // Verificar token
    if (pathname === '/api/me' && request.method === 'GET') {
      const token = request.headers.authorization?.replace('Bearer ', '');
      const user = validateSession(token, db);

      if (!user) {
        response.writeHead(401, { 'Content-Type': 'application/json' });
        response.end(JSON.stringify({ error: 'Não autenticado' }));
        return;
      }

      response.writeHead(200, { 'Content-Type': 'application/json' });
      response.end(JSON.stringify({
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        progress: user.progress,
        correctAnswers: user.correctAnswers,
        totalAnswers: user.totalAnswers,
        streak: user.streak
      }));
      return;
    }

    // Logout
    if (pathname === '/api/logout' && request.method === 'POST') {
      const token = request.headers.authorization?.replace('Bearer ', '');
      db.sessions = db.sessions.filter(s => s.token !== token);
      saveDB(db);

      response.writeHead(200, { 'Content-Type': 'application/json' });
      response.end(JSON.stringify({ message: 'Desconectado com sucesso' }));
      return;
    }

    // Admin - Listar usuários
    if (pathname === '/api/admin/users' && request.method === 'GET') {
      const token = request.headers.authorization?.replace('Bearer ', '');
      const user = validateSession(token, db);

      if (!user || user.role !== 'admin') {
        response.writeHead(403, { 'Content-Type': 'application/json' });
        response.end(JSON.stringify({ error: 'Acesso negado' }));
        return;
      }

      response.writeHead(200, { 'Content-Type': 'application/json' });
      response.end(JSON.stringify({
        users: db.users.map(u => ({
          id: u.id,
          name: u.name,
          email: u.email,
          role: u.role,
          createdAt: u.createdAt,
          progress: u.progress,
          correctAnswers: u.correctAnswers,
          totalAnswers: u.totalAnswers
        }))
      }));
      return;
    }

    // Admin - Atualizar usuário
    if (pathname.match(/^\/api\/admin\/users\/\d+$/) && request.method === 'PUT') {
      const token = request.headers.authorization?.replace('Bearer ', '');
      const user = validateSession(token, db);

      if (!user || user.role !== 'admin') {
        response.writeHead(403, { 'Content-Type': 'application/json' });
        response.end(JSON.stringify({ error: 'Acesso negado' }));
        return;
      }

      const userId = parseInt(pathname.split('/').pop());
      const body = await parseJSON(request);
      const targetUser = db.users.find(u => u.id === userId);

      if (!targetUser) {
        response.writeHead(404, { 'Content-Type': 'application/json' });
        response.end(JSON.stringify({ error: 'Usuário não encontrado' }));
        return;
      }

      if (body.name) targetUser.name = body.name;
      if (body.role) targetUser.role = body.role;
      if (body.progress) targetUser.progress = body.progress;

      saveDB(db);

      response.writeHead(200, { 'Content-Type': 'application/json' });
      response.end(JSON.stringify({ message: 'Usuário atualizado' }));
      return;
    }

    // Admin - Deletar usuário
    if (pathname.match(/^\/api\/admin\/users\/\d+$/) && request.method === 'DELETE') {
      const token = request.headers.authorization?.replace('Bearer ', '');
      const user = validateSession(token, db);

      if (!user || user.role !== 'admin') {
        response.writeHead(403, { 'Content-Type': 'application/json' });
        response.end(JSON.stringify({ error: 'Acesso negado' }));
        return;
      }

      const userId = parseInt(pathname.split('/').pop());
      db.users = db.users.filter(u => u.id !== userId);
      db.sessions = db.sessions.filter(s => s.userId !== userId);

      saveDB(db);

      response.writeHead(200, { 'Content-Type': 'application/json' });
      response.end(JSON.stringify({ message: 'Usuário deletado' }));
      return;
    }

    // Atualizar progresso
    if (pathname === '/api/progress' && request.method === 'POST') {
      const token = request.headers.authorization?.replace('Bearer ', '');
      const user = validateSession(token, db);

      if (!user) {
        response.writeHead(401, { 'Content-Type': 'application/json' });
        response.end(JSON.stringify({ error: 'Não autenticado' }));
        return;
      }

      const body = await parseJSON(request);
      const { module, correct } = body;

      if (module && user.progress) {
        user.progress[module] = (user.progress[module] || 0) + (correct ? 1 : 0);
      }

      if (correct !== undefined) {
        user.correctAnswers = (user.correctAnswers || 0) + (correct ? 1 : 0);
        user.totalAnswers = (user.totalAnswers || 0) + 1;
      }

      user.lastStudy = new Date().toISOString();
      saveDB(db);

      response.writeHead(200, { 'Content-Type': 'application/json' });
      response.end(JSON.stringify({ message: 'Progresso atualizado' }));
      return;
    }

    // Servir arquivos estáticos
    if (pathname === '/' || pathname === '/index.html') {
      serveStatic('/index.html', response);
    } else if (pathname === '/admin' || pathname === '/admin/') {
      serveStatic('/admin.html', response);
    } else if (pathname.startsWith('/public/')) {
      serveStatic(pathname.replace('/public/', ''), response);
    } else if (pathname.match(/\.(html|css|js|json|png|jpg|svg)$/)) {
      serveStatic(pathname, response);
    } else {
      serveStatic('/index.html', response);
    }
  } catch (error) {
    console.error('Erro:', error);
    response.writeHead(500, { 'Content-Type': 'application/json' });
    response.end(JSON.stringify({ error: 'Erro interno do servidor' }));
  }
});

server.listen(PORT, () => {
  console.log(`🇯🇵 CIL Recanto Japonês - Servidor rodando em http://localhost:${PORT}`);
});
