# 🇯🇵 CIL Recanto Japonês - Plataforma de Estudo

Uma plataforma moderna e completa para ensino de japonês com painel administrativo integrado.

## 🚀 Características

- ✅ Dashboard interativo para alunos
- ✅ Módulos de aprendizado: Hiragana, Katakana, Kanji, Vocabulário
- ✅ Sistema de autenticação seguro
- ✅ Painel administrativo completo
- ✅ Rastreamento de progresso em tempo real
- ✅ Análises e estatísticas de desempenho
- ✅ Design responsivo e moderno
- ✅ Sem dependências externas (apenas Node.js)

## 📋 Pré-requisitos

- Node.js 18+ instalado
- Acesso a uma porta (padrão: 3000)

## 🔧 Instalação

1. **Clone ou extraia o projeto:**
```bash
cd cil-recanto-japones
```

2. **Instale as dependências:**
```bash
npm install
```

3. **Inicie o servidor:**
```bash
npm start
```

O servidor estará rodando em `http://localhost:3000`

## 🎯 Primeiro Uso

### Criar Primeira Conta
1. Acesse `http://localhost:3000`
2. Clique em "Registre-se"
3. Preencha os dados (Nome, Email, Senha)
4. **A primeira conta criada será automaticamente admin**

### Acessar Painel Admin
1. Faça login com a conta admin
2. Clique em "Perfil" ou acesse `http://localhost:3000/admin`

## 📱 Interfaces

### Para Alunos: `/`
- Dashboard com progresso
- Módulos de aprendizado
- Rastreamento de atividades
- Estatísticas pessoais

### Para Administradores: `/admin`
- Gerenciamento de usuários
- Análises globais
- Configurações do sistema
- Exportação de dados

## 🔐 Sistema de Autenticação

- Senhas armazenadas com hash SHA-256
- Tokens JWT com expiração de 30 dias
- Controle de acesso baseado em papéis (RBAC)
- Papéis: `student` (aluno) e `admin` (administrador)

## 💾 Armazenamento de Dados

O sistema usa JSON para armazenamento local:
- Local: `./data/database.json`
- Backup automático com salvar
- Estrutura simples e portável

## 🎓 Módulos de Aprendizado

### Hiragana (ひらがな)
- 46 caracteres básicos
- Sistema de memorização
- Progressão rastreada

### Katakana (カタカナ)
- 46 caracteres básicos
- Similares ao Hiragana
- Para palavras estrangeiras

### Kanji (漢字)
- Caracteres complexos
- Significado + pronúncia
- Progressão gradual

### Vocabulário (語彙)
- Palavras comuns
- Expressões úteis
- Contexto de uso

## 📊 Estatísticas e Análises

O painel admin fornece:
- Total de usuários e alunos
- Taxa média de acerto
- Progresso por módulo
- Usuários mais ativos
- Atividade recente

## 🔄 Fluxo de Trabalho

```
[Novo Usuário] → [Registrar] → [Primeira Conta = Admin]
                                       ↓
                          [Estudar] + [Admin]
                              ↓            ↓
                        [Dashboard]  [Painel Admin]
                              ↓            ↓
                        [Progresso] [Gerenciar Usuários]
```

## 🛠️ API Endpoints

### Autenticação
- `POST /api/register` - Registrar novo usuário
- `POST /api/login` - Fazer login
- `POST /api/logout` - Desconectar
- `GET /api/me` - Dados do usuário autenticado

### Admin (requer token + role=admin)
- `GET /api/admin/users` - Listar todos os usuários
- `PUT /api/admin/users/:id` - Atualizar usuário
- `DELETE /api/admin/users/:id` - Deletar usuário

### Progresso
- `POST /api/progress` - Registrar progresso de estudo

## 🌐 Configuração de Porta

Para usar porta diferente de 3000:
```bash
PORT=8080 npm start
```

## 📦 Estrutura do Projeto

```
cil-recanto-japones/
├── server.js              # Servidor Node.js
├── package.json           # Dependências
├── README.md             # Este arquivo
├── public/
│   ├── index.html        # Dashboard do aluno
│   └── admin.html        # Painel administrativo
└── data/
    └── database.json     # Banco de dados (criado automaticamente)
```

## 🐛 Solução de Problemas

### Porta em uso
```bash
# Linux/Mac
sudo lsof -i :3000
kill -9 <PID>

# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### Erro ao conectar
- Verifique se o servidor está rodando
- Confirme a porta correta
- Limpe o cache do navegador

### Dados corrompidos
- Delete `data/database.json`
- Reinicie o servidor
- Sistema será recriado automaticamente

## 🔐 Segurança

- Sempre use HTTPS em produção
- Altere senhas padrão imediatamente
- Faça backup regular do banco de dados
- Implemente autenticação de dois fatores para admin

## 📈 Escalabilidade

Para production:
1. Migrar para banco de dados robusto (PostgreSQL, MongoDB)
2. Implementar API REST com framework (Express, Fastify)
3. Adicionar autenticação OAuth
4. Implementar logs e monitoramento
5. Usar Docker para containerização

## 📞 Suporte

Para problemas ou sugestões, entre em contato com:
- Email: contato@cil-recanto.com
- Telefone: (61) 9999-9999

## 📄 Licença

Todos os direitos reservados © 2024 CIL Recanto Japonês

## 🎉 Enjoy Your Learning!

学習を楽しんでください！(Gakushū wo tanoshinde kudasai!)
